<section>
    <div class="container">
        <div class="row d-flex justify-content-center">
            <div class="col-md-4">
                <img src="assets/images/cs.png" alt=""style="width:100%;">
            </div>
        </div>
    </div>
    </section>